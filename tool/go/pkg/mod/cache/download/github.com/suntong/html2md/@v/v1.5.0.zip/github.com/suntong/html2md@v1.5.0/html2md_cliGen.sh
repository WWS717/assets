 easygen ../../go-easygen/wireframe/cli-ext html2md_cli | gofmt > html2md_cliDef.go
