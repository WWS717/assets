<?php

return array(
	'sample1'=>array(
		'title'=>'test post 1',
		'content'=>"This blog is powered by [Yii framework](http://www.yiiframework.com).",
		'status'=>2,
		'create_time'=>1230952187,
		'update_time'=>1230952187,
		'author_id'=>1,
		'tags'=>'yii, blog',
	),
);
